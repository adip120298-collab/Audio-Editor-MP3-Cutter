package com.adip.mp3cutter

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max

class WaveformView(ctx: Context) : View(ctx) {
    var pcm: Pcm? = null
        set(v) { field = v; peaks = null; invalidate() }
    var selA = 0f
    var selB = 1f
    @Volatile var playPos = -1f
    var onChange: (() -> Unit)? = null
    private var peaks: FloatArray? = null
    private var drag = 0
    private val pBar = Paint().apply { color = 0xFF6366F1.toInt(); strokeWidth = 2f }
    private val pSel = Paint().apply { color = 0x33FF8A1F }
    private val pHandle = Paint().apply { color = 0xFFFF8A1F.toInt(); strokeWidth = 5f; isAntiAlias = true }
    private val pPlay = Paint().apply { color = 0xFF16A34A.toInt(); strokeWidth = 3f }
    private val pBg = Paint().apply { color = 0xFF1E1B4B.toInt() }
    private val pTxt = Paint().apply { color = 0xFFFFFFFF.toInt(); textSize = 36f; isAntiAlias = true }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { peaks = null }

    private fun calc() {
        val p = pcm ?: return
        if (width <= 0) return
        val pk = FloatArray(width)
        for (x in 0 until width) {
            val s = (x.toLong() * p.frames / width).toInt()
            val e = max(s + 1, ((x + 1).toLong() * p.frames / width).toInt())
            val step = max(1, (e - s) / 64)
            var m = 0
            var i = s
            while (i < e && i < p.frames) { m = max(m, abs(p.data[i * p.ch].toInt())); i += step }
            pk[x] = m / 32768f
        }
        peaks = pk
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, pBg)
        val p = pcm
        if (p == null) { c.drawText("Buka file audio / video", 24f, h / 2, pTxt); return }
        if (peaks == null) calc()
        val pk = peaks ?: return
        val mid = h / 2
        for (x in pk.indices) { val y = pk[x] * mid * 0.95f; c.drawLine(x.toFloat(), mid - y, x.toFloat(), mid + y, pBar) }
        val xa = selA * w; val xb = selB * w
        c.drawRect(xa, 0f, xb, h, pSel)
        c.drawLine(xa, 0f, xa, h, pHandle); c.drawLine(xb, 0f, xb, h, pHandle)
        c.drawCircle(xa, 18f, 14f, pHandle); c.drawCircle(xb, h - 18f, 14f, pHandle)
        if (playPos >= 0f) c.drawLine(playPos * w, 0f, playPos * w, h, pPlay)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (pcm == null) return true
        parent?.requestDisallowInterceptTouchEvent(true)
        val f = (e.x / width).coerceIn(0f, 1f)
        when (e.action) {
            MotionEvent.ACTION_DOWN -> drag = if (abs(f - selA) <= abs(f - selB)) 1 else 2
            MotionEvent.ACTION_MOVE -> {
                val gap = 0.002f
                if (drag == 1) selA = f.coerceAtMost(selB - gap) else if (drag == 2) selB = f.coerceAtLeast(selA + gap)
                invalidate(); onChange?.invoke()
            }
        }
        return true
    }
}
