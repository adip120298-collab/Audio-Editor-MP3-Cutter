package com.adip.mp3cutter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private var pcm: Pcm? = null
    private var undo: Pcm? = null
    private var name = "audio"
    @Volatile private var playing = false
    private lateinit var wave: WaveformView
    private lateinit var info: TextView
    private lateinit var status: TextView
    private lateinit var etStart: EditText
    private lateinit var etEnd: EditText
    private lateinit var etFade: EditText
    private lateinit var etVol: EditText
    private lateinit var etGap: EditText
    private lateinit var etSplit: EditText
    private lateinit var etSpeed: EditText
    private lateinit var etPitch: EditText
    private lateinit var etSil: EditText
    private lateinit var etLoop: EditText
    private lateinit var spFmt: Spinner

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; textSize = 13f; setOnClickListener { f() } }
    private fun field(def: String) = EditText(this).apply {
        setText(def); textSize = 14f; setSingleLine()
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    }
    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        v.forEach { addView(it, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)) }
    }
    private fun lbl(t: String) = TextView(this).apply { text = t; textSize = 13f; setTextColor(Color.DKGRAY) }
    private fun num(e: EditText, d: Double) = e.text.toString().replace(',', '.').toDoubleOrNull() ?: d
    private fun toast(m: String) { status.text = m }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(24)) }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_bars)
            background = GradientDrawable().apply { setColor(0xFF1E1B4B.toInt()); cornerRadius = dp(14).toFloat() }
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0)
            addView(TextView(context).apply { text = "Audio Editor & MP3 Cutter"; textSize = 19f; setTypeface(null, Typeface.BOLD) })
            addView(TextView(context).apply { text = "Offline • Gratis • Tanpa watermark"; textSize = 12f; setTextColor(Color.GRAY) })
        }
        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(logo, LinearLayout.LayoutParams(dp(56), dp(56)))
            addView(titles)
        })
        wave = WaveformView(this)
        root.addView(wave, LinearLayout.LayoutParams(MATCH_PARENT, dp(160)).apply { topMargin = dp(12) })
        info = lbl("Belum ada file."); root.addView(info)
        status = TextView(this).apply { textSize = 13f; setTextColor(0xFF4338CA.toInt()) }
        root.addView(status)
        wave.onChange = { sync() }

        etStart = field("0.000"); etEnd = field("0.000")
        root.addView(row(lbl("Mulai (detik)"), etStart, lbl("Akhir (detik)"), etEnd))
        root.addView(btn("Terapkan waktu (presisi milidetik)") { applyFields() })

        root.addView(row(btn("📂 Buka File") { pick(1, false) }, btn("➕ Gabung File") { pick(2, true) }))
        etGap = field("0.5")
        root.addView(row(lbl("Jeda antar file gabung (detik)"), etGap))
        root.addView(row(btn("▶ Putar Pilihan") { play() }, btn("■ Stop") { playing = false }))
        root.addView(row(btn("✂ Trim (simpan pilihan)") { trim() }, btn("🗑 Hapus pilihan") { delSel() }))
        etSplit = field("60")
        root.addView(row(lbl("Split per (detik)"), etSplit))
        root.addView(row(btn("Split per durasi") { splitDur() }, btn("Split di Mulai") { splitAt() }))
        etFade = field("2")
        root.addView(row(lbl("Durasi fade (1-5 dtk)"), etFade))
        root.addView(row(btn("Fade In") { fade(true) }, btn("Fade Out") { fade(false) }))
        etVol = field("150")
        root.addView(row(lbl("Volume (%)"), etVol))
        root.addView(row(btn("Atur Volume") { vol() }, btn("Normalize") { norm() }))
        etLoop = field("2")
        root.addView(row(lbl("Ulangi pilihan (kali)"), etLoop))
        root.addView(btn("🔁 Salin & tempel / loop pilihan") { loopSel() })
        etSpeed = field("1.0")
        root.addView(row(lbl("Kecepatan 0.5-2.0x"), etSpeed))
        root.addView(btn("Terapkan kecepatan (nada tetap)") { speed() })
        etPitch = field("0")
        root.addView(row(lbl("Nada (semiton -12..+12)"), etPitch))
        root.addView(btn("Terapkan nada (kecepatan tetap)") { pitch() })
        etSil = field("-45")
        root.addView(row(lbl("Batas hening (dB)"), etSil))
        root.addView(btn("🔇 Hapus bagian hening") { silence() })
        root.addView(btn("📦 Compressor: kecilkan ukuran (mono 22 kHz)") { compress() })
        root.addView(btn("🔄 Konversi Batch (maks 10 file)") { pick(3, true) })
        spFmt = Spinner(this)
        spFmt.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, FORMATS.map { it.label })
        root.addView(lbl("Format simpan")); root.addView(spFmt)
        root.addView(row(btn("💾 Simpan Pilihan") { save(false) }, btn("💾 Simpan Semua") { save(true) }))
        root.addView(btn("↩ Undo") { undoOp() })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    // ---------- helpers ----------
    private fun range(): Pair<Int, Int>? {
        val p = pcm
        if (p == null) { toast("Buka file dulu."); return null }
        val a = (wave.selA * p.frames).toInt().coerceIn(0, p.frames - 1)
        val b = (wave.selB * p.frames).toInt().coerceIn(a + 1, p.frames)
        return a to b
    }

    private fun sync() {
        val p = pcm ?: return
        val r = range() ?: return
        etStart.setText(String.format(Locale.US, "%.3f", r.first.toDouble() / p.rate))
        etEnd.setText(String.format(Locale.US, "%.3f", r.second.toDouble() / p.rate))
        info.text = String.format(Locale.US, "%s • %.2f dtk • %d Hz • %s • pilihan %.3f dtk", name,
            p.frames.toDouble() / p.rate, p.rate, if (p.ch == 1) "mono" else "stereo", (r.second - r.first).toDouble() / p.rate)
    }

    private fun applyFields() {
        val p = pcm ?: return toast("Buka file dulu.")
        val len = p.frames.toDouble() / p.rate
        val s = num(etStart, 0.0).coerceIn(0.0, len)
        val e = num(etEnd, len).coerceIn(s + 0.001, len)
        wave.selA = (s / len).toFloat(); wave.selB = (e / len).toFloat()
        wave.invalidate(); sync()
    }

    private fun setPcm(n: Pcm, resetSel: Boolean) {
        undo = pcm; pcm = n; wave.pcm = n
        if (resetSel) { wave.selA = 0f; wave.selB = 1f }
        sync()
    }

    private fun undoOp() { val u = undo ?: return toast("Tidak ada yang di-undo."); pcm = u; undo = null; wave.pcm = u; wave.selA = 0f; wave.selB = 1f; sync(); toast("Undo.") }

    private fun work(msg: String, block: () -> Unit) {
        status.text = msg
        Thread {
            try { block() } catch (e: Throwable) { runOnUiThread { status.text = "Gagal: ${e.message}" } }
        }.start()
    }

    private fun baseName(u: Uri): String {
        var n = "audio"
        contentResolver.query(u, null, null, null, null)?.use { if (it.moveToFirst()) { val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) n = it.getString(i) } }
        return n.substringBeforeLast('.')
    }

    // ---------- buka / gabung ----------
    private fun pick(code: Int, multi: Boolean) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*"))
        if (multi) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, code)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        val cd = data.clipData
        if (cd != null) { for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) } else data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        if (req == 1) {
            playing = false
            work("Membaca file...") {
                val p = Engine.decode(this, uris[0]); val n = baseName(uris[0])
                runOnUiThread { name = n; undo = null; pcm = p; wave.pcm = p; wave.selA = 0f; wave.selB = 1f; sync(); status.text = "File dimuat." }
            }
        } else if (req == 3) {
            val f = spFmt.selectedItemPosition
            work("Konversi batch...") {
                var ok = 0
                val list = uris.take(10)
                for ((i, u) in list.withIndex()) {
                    runOnUiThread { status.text = "Konversi ${i + 1}/${list.size}..." }
                    Engine.save(this, Engine.decode(this, u), baseName(u), f)
                    ok++
                }
                runOnUiThread { status.text = "Batch selesai: $ok file di folder AudioEditor." }
            }
        } else {
            val gap = num(etGap, 0.5)
            val cur = pcm
            work("Menggabungkan...") {
                val parts = mutableListOf<Pcm>()
                if (cur != null) parts.add(cur)
                for (u in uris) { if (parts.size >= 10) break; parts.add(Engine.decode(this, u)) }
                if (parts.size < 2) throw IllegalStateException("Pilih minimal 2 file (maks 10)")
                val m = Engine.merge(parts, gap)
                runOnUiThread { if (cur == null) name = "gabungan"; setPcm(m, true); status.text = "Digabung: ${parts.size} file." }
            }
        }
    }

    // ---------- edit ----------
    private fun trim() { val r = range() ?: return; setPcm(Engine.slice(pcm!!, r.first, r.second), true); toast("Trim selesai.") }
    private fun delSel() {
        val r = range() ?: return
        if (r.second - r.first >= pcm!!.frames) return toast("Pilihan tidak boleh seluruh file.")
        setPcm(Engine.cut(pcm!!, r.first, r.second), true); toast("Bagian terpilih dihapus.")
    }
    private fun fade(inn: Boolean) {
        val r = range() ?: return
        setPcm(Engine.fade(pcm!!, r.first, r.second, num(etFade, 2.0).coerceIn(1.0, 5.0), inn), false); toast(if (inn) "Fade in diterapkan." else "Fade out diterapkan.")
    }
    private fun vol() { val r = range() ?: return; setPcm(Engine.gain(pcm!!, r.first, r.second, (num(etVol, 100.0) / 100.0).toFloat()), false); toast("Volume diubah.") }
    private fun norm() { if (range() == null) return; setPcm(Engine.normalize(pcm!!), false); toast("Normalize selesai.") }

    private fun heavy(msg: String, op: (Pcm) -> Pcm) {
        val p = pcm ?: return toast("Buka file dulu.")
        work(msg) { val n = op(p); runOnUiThread { setPcm(n, true); status.text = "Selesai." } }
    }
    private fun speed() { val s = num(etSpeed, 1.0).coerceIn(0.5, 2.0); heavy("Mengubah kecepatan...") { Engine.stretch(it, s) } }
    private fun pitch() { val r = Math.pow(2.0, num(etPitch, 0.0).coerceIn(-12.0, 12.0) / 12.0); heavy("Mengubah nada...") { Engine.pitch(it, r) } }
    private fun silence() { val db = num(etSil, -45.0).coerceIn(-80.0, -10.0); heavy("Menghapus hening...") { Engine.removeSilence(it, db, 0.3) } }
    private fun compress() { heavy("Mengecilkan...") { Engine.convert(it, 22050, 1) } }
    private fun loopSel() {
        val r = range() ?: return
        val t = num(etLoop, 2.0).toInt().coerceIn(2, 20)
        val a = r.first; val b = r.second
        val p = pcm!!
        if ((b - a).toLong() * (t - 1) + p.frames > 100_000_000L) return toast("Hasil terlalu besar.")
        heavy("Menggandakan...") { Engine.repeatSel(it, a, b, t) }
    }

    // ---------- putar ----------
    private fun play() {
        val p = pcm ?: return toast("Buka file dulu.")
        val r = range() ?: return
        playing = false
        Thread {
            Thread.sleep(80)
            playing = true
            val mask = if (p.ch == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
            val minBuf = AudioTrack.getMinBufferSize(p.rate, mask, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(p.rate).setChannelMask(mask).build())
                .setBufferSizeInBytes(max(minBuf, 16384)).setTransferMode(AudioTrack.MODE_STREAM).build()
            t.play()
            var pos = r.first * p.ch
            val end = r.second * p.ch
            while (playing && pos < end) {
                val n = min(4096 * p.ch, end - pos)
                t.write(p.data, pos, n)
                pos += n
                wave.playPos = (pos / p.ch).toFloat() / p.frames
                wave.postInvalidate()
            }
            t.stop(); t.release()
            playing = false; wave.playPos = -1f; wave.postInvalidate()
        }.start()
    }

    // ---------- simpan / split ----------
    private fun save(all: Boolean) {
        val p = pcm ?: return toast("Buka file dulu.")
        val r = if (all) 0 to p.frames else range() ?: return
        val f = spFmt.selectedItemPosition
        val nm = name + if (all) "_edit" else "_potong"
        work("Menyimpan...") { val where = Engine.save(this, Engine.slice(p, r.first, r.second), nm, f); runOnUiThread { status.text = "Tersimpan: $where" } }
    }

    private fun splitDur() {
        val p = pcm ?: return toast("Buka file dulu.")
        val per = max(1, (num(etSplit, 60.0) * p.rate).toInt())
        val f = spFmt.selectedItemPosition
        val nm = name
        work("Memecah file...") {
            var a = 0; var k = 1
            while (a < p.frames) {
                val b = min(p.frames, a + per)
                if (p.frames - b < per / 10) { Engine.save(this, Engine.slice(p, a, p.frames), "${nm}_bagian$k", f); break }
                Engine.save(this, Engine.slice(p, a, b), "${nm}_bagian$k", f)
                a = b; k++
                runOnUiThread { status.text = "Memecah... bagian $k" }
            }
            runOnUiThread { status.text = "Split selesai ($k bagian) di folder AudioEditor." }
        }
    }

    private fun splitAt() {
        val p = pcm ?: return toast("Buka file dulu.")
        val a = range()?.first ?: return
        if (a <= 0) return toast("Geser garis Mulai ke titik pemisah dulu.")
        val f = spFmt.selectedItemPosition
        val nm = name
        work("Memecah file...") {
            Engine.save(this, Engine.slice(p, 0, a), "${nm}_bagian1", f)
            Engine.save(this, Engine.slice(p, a, p.frames), "${nm}_bagian2", f)
            runOnUiThread { status.text = "Split selesai (2 bagian) di folder AudioEditor." }
        }
    }
}
