package com.adip.mp3cutter

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Waveform dengan dua pegangan. mode 0 = pangkas dari dua sisi (simpan pilihan), mode 1 = pangkas bagian tengah (buang pilihan). */
class WaveformView(ctx: Context) : View(ctx) {
    var pcm: Pcm? = null
        set(v) { field = v; peaks = null; vs = 0f; ve = 1f; invalidate() }
    var selA = 0f
    var selB = 1f
    var mode = 0
        set(v) { field = v; invalidate() }
    @Volatile var playPos = -1f
    var onChange: (() -> Unit)? = null
    private var vs = 0f
    private var ve = 1f
    private var peaks: FloatArray? = null
    private var drag = 0
    private var last = 1
    private val acc = 0xFFE91E63.toInt()
    private val pBar = Paint().apply { color = 0xFFBDBDBD.toInt(); strokeWidth = 2f }
    private val pDim = Paint().apply { color = 0xAA000000.toInt() }
    private val pCut = Paint().apply { color = 0x66E91E63 }
    private val pKeep = Paint().apply { color = 0x22FFFFFF }
    private val pHandle = Paint().apply { color = acc; strokeWidth = 5f; isAntiAlias = true }
    private val pPlay = Paint().apply { color = 0xFFFFFFFF.toInt(); strokeWidth = 4f; isAntiAlias = true }
    private val pBg = Paint().apply { color = 0xFF262626.toInt() }
    private val pTxt = Paint().apply { color = 0xFFFFFFFF.toInt(); textSize = 40f; isAntiAlias = true; textAlign = Paint.Align.CENTER }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { peaks = null }

    fun zoom(inn: Boolean) {
        var span = ve - vs
        span = if (inn) max(0.004f, span / 2) else min(1f, span * 2)
        val c = if (last == 1) selA else selB
        vs = (c - span / 2).coerceIn(0f, 1f - span)
        ve = vs + span
        peaks = null; invalidate()
    }

    private fun fx(f: Float) = (f - vs) / (ve - vs) * width
    private fun xf(x: Float) = vs + (x / width) * (ve - vs)

    private fun calc() {
        val p = pcm ?: return
        if (width <= 0) return
        val pk = FloatArray(width)
        for (x in 0 until width) {
            val s = (xf(x.toFloat()) * p.frames).toInt().coerceIn(0, p.frames - 1)
            val e = (xf(x + 1f) * p.frames).toInt().coerceIn(s + 1, p.frames)
            val step = max(1, (e - s) / 64)
            var m = 0
            var i = s
            while (i < e) { m = max(m, abs(p.data[i * p.ch].toInt())); i += step }
            pk[x] = m / 32768f
        }
        peaks = pk
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, pBg)
        if (pcm == null) { c.drawText("Buka file audio / video", w / 2, h / 2, pTxt); return }
        if (peaks == null) calc()
        val pk = peaks ?: return
        val mid = h / 2
        for (x in pk.indices) { val y = max(1f, pk[x] * mid * 0.95f); c.drawLine(x.toFloat(), mid - y, x.toFloat(), mid + y, pBar) }
        val xa = fx(selA); val xb = fx(selB)
        if (mode == 0) { c.drawRect(0f, 0f, xa, h, pDim); c.drawRect(xb, 0f, w, h, pDim); c.drawRect(xa, 0f, xb, h, pKeep) }
        else c.drawRect(xa, 0f, xb, h, pCut)
        c.drawLine(xa, 0f, xa, h, pHandle); c.drawLine(xb, 0f, xb, h, pHandle)
        c.drawCircle(xa, h * 0.3f, 26f, pHandle); c.drawCircle(xb, h * 0.7f, 26f, pHandle)
        c.drawText("‹", xa, h * 0.3f + 14f, pTxt); c.drawText("›", xb, h * 0.7f + 14f, pTxt)
        if (playPos >= 0f) { val xp = fx(playPos); c.drawLine(xp, 0f, xp, h, pPlay); c.drawCircle(xp, 12f, 9f, pPlay) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (pcm == null) return true
        parent?.requestDisallowInterceptTouchEvent(true)
        val f = xf(e.x).coerceIn(0f, 1f)
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { drag = if (abs(e.x - fx(selA)) <= abs(e.x - fx(selB))) 1 else 2; last = drag }
            MotionEvent.ACTION_MOVE -> {
                val gap = 0.0005f
                if (drag == 1) selA = f.coerceAtMost(selB - gap) else if (drag == 2) selB = f.coerceAtLeast(selA + gap)
                invalidate(); onChange?.invoke()
            }
        }
        return true
    }
}
