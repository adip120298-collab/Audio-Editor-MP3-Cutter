package com.adip.mp3cutter

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

class MainActivity : Activity() {
    private val BG = 0xFF1E1E1E.toInt()
    private val ACC = 0xFFE91E63.toInt()
    private val PANEL = 0xFF2E2E2E.toInt()

    private var pcm: Pcm? = null
    private var undo: Pcm? = null
    private var name = "audio"
    private var mode = 0
    private var fmtIdx = 7
    private var mergeGap = 0.5
    @Volatile private var playing = false
    @Volatile private var cur = 0
    @Volatile private var gen = 0
    private var prevPcm: Pcm? = null
    private var pa = 0
    private var pb = 0
    private var pmode = 0
    private var lastKey = ""
    private lateinit var wave: WaveformView
    private lateinit var info: TextView
    private lateinit var status: TextView
    private lateinit var tvStart: TextView
    private lateinit var tvEnd: TextView
    private lateinit var tvDur: TextView
    private lateinit var tabA: TextView
    private lateinit var tabB: TextView
    private lateinit var btnPlay: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun ui(f: () -> Unit) = runOnUiThread(f)
    private fun toast(m: String) { status.text = m }
    private fun rounded(c: Int, r: Int = 20) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun txt(t: String, size: Float = 14f, color: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = size; setTextColor(color) }
    private fun num(e: EditText, d: Double) = e.text.toString().replace(',', '.').toDoubleOrNull() ?: d

    private fun pill(t: String, f: () -> Unit) = txt(t, 13f, ACC).apply {
        gravity = Gravity.CENTER; setPadding(dp(16), dp(8), dp(16), dp(8))
        background = GradientDrawable().apply { setStroke(dp(1), ACC); cornerRadius = dp(20).toFloat() }
        setOnClickListener { f() }
    }

    private fun tool(icon: String, label: String, f: () -> Unit) = txt("$icon\n$label", 11f).apply {
        gravity = Gravity.CENTER; setPadding(dp(6), dp(10), dp(6), dp(10)); minWidth = dp(74)
        setOnClickListener { f() }
    }

    private fun ask(title: String, def: String, ok: (Double) -> Unit) {
        val et = EditText(this).apply {
            setText(def); setSingleLine(); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> ok(num(et, def.toDouble())) }
            .setNegativeButton("Batal", null).show()
    }

    private fun nb(t: String, start: Boolean, sign: Int) = txt(t, 18f).apply {
        gravity = Gravity.CENTER; setPadding(dp(10), dp(6), dp(10), dp(6))
        setOnClickListener { nudge(start, sign * 0.1) }
        setOnLongClickListener { nudge(start, sign * 0.01); true }
    }

    private fun group(start: Boolean, tv: TextView) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        background = rounded(ACC)
        addView(nb("−", start, -1)); addView(tv); addView(nb("+", start, 1))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        // header
        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(10), dp(16), dp(10))
            addView(txt("Pemotong Audio", 19f).apply { setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(pill("SIMPAN") { saveDialog() })
        })
        // tab mode
        tabA = txt("✂ Pangkas dari dua sisi", 13f).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(12), dp(8), dp(12)); setOnClickListener { setMode(0) } }
        tabB = txt("✂ Pangkas bagian tengah", 13f).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(12), dp(8), dp(12)); setOnClickListener { setMode(1) } }
        root.addView(LinearLayout(this).apply {
            background = rounded(PANEL, 10)
            addView(tabA, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)); addView(tabB, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(dp(12), 0, dp(12), dp(10)) })
        // waveform
        wave = WaveformView(this)
        wave.onChange = { sync() }
        root.addView(wave, LinearLayout.LayoutParams(MATCH_PARENT, dp(200)))
        info = txt("Belum ada file. Buka file lewat menu di bawah.", 12f, Color.LTGRAY)
        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(6), dp(10), dp(6))
            addView(info, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(txt("🔍−", 16f).apply { setPadding(dp(10), dp(4), dp(10), dp(4)); setOnClickListener { wave.zoom(false) } })
            addView(txt("🔍+", 16f).apply { setPadding(dp(10), dp(4), dp(10), dp(4)); setOnClickListener { wave.zoom(true) } })
        })
        // waktu
        tvStart = txt("00:00.00", 13f).apply { gravity = Gravity.CENTER }
        tvEnd = txt("00:00.00", 13f).apply { gravity = Gravity.CENTER }
        tvDur = txt("00:00.0", 14f, ACC).apply { gravity = Gravity.CENTER }
        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(4))
            addView(group(true, tvStart))
            addView(tvDur, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(group(false, tvEnd))
        })
        root.addView(txt("Tap − / + = 0,1 detik. Tahan = 0,01 detik.", 11f, Color.GRAY).apply { gravity = Gravity.CENTER })
        // transport
        btnPlay = txt("▶", 30f).apply {
            gravity = Gravity.CENTER; setTextColor(Color.BLACK); background = rounded(Color.WHITE, 40)
            setOnClickListener { togglePlay() }
        }
        fun tp(t: String, f: () -> Unit) = txt(t, 22f).apply { gravity = Gravity.CENTER; setPadding(dp(10), dp(10), dp(10), dp(10)); setOnClickListener { f() } }
        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(24), 0, dp(10))
            addView(tp("⏮") { cur = 0; if (prevPcm != null) updatePlayhead() })
            addView(tp("⏪") { seekBy(-5.0) })
            addView(btnPlay, LinearLayout.LayoutParams(dp(72), dp(72)).apply { setMargins(dp(10), 0, dp(10), 0) })
            addView(tp("⏩") { seekBy(5.0) })
            addView(tp("⏭") { prevPcm?.let { cur = max(0, it.frames - 1); updatePlayhead() } })
        })
        root.addView(View(this), LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        status = txt("", 12f, 0xFFFF80AB.toInt()).apply { setPadding(dp(14), dp(4), dp(14), dp(6)) }
        root.addView(status)
        // toolbar
        val bar = LinearLayout(this).apply { setBackgroundColor(PANEL); setPadding(dp(4), dp(2), dp(4), dp(2)) }
        bar.addView(tool("📂", "Buka") { pick(1, false) })
        bar.addView(tool("🎤", "Pisah\nVokal") { separate() })
        bar.addView(tool("🔊", "Fade masuk") { fadeOp(true) })
        bar.addView(tool("🔉", "Fade keluar") { fadeOp(false) })
        bar.addView(tool("🔈", "Volume") { ask("Volume pilihan (%)", "150") { v -> val r = range(); if (r != null) setPcm(Engine.gain(pcm!!, r.first, r.second, (v / 100.0).toFloat()), false) } })
        bar.addView(tool("📈", "Normalize") { if (range() != null) setPcm(Engine.normalize(pcm!!), false) })
        bar.addView(tool("⏩", "Kecepatan") { ask("Kecepatan (0.5-2.0)", "1.0") { v -> heavy("Mengubah kecepatan...") { Engine.stretch(it, v.coerceIn(0.5, 2.0)) } } })
        bar.addView(tool("🎵", "Nada") { ask("Nada (semiton -12..+12)", "0") { v -> heavy("Mengubah nada...") { Engine.pitch(it, 2.0.pow(v.coerceIn(-12.0, 12.0) / 12.0)) } } })
        bar.addView(tool("🔇", "Hapus\nhening") { ask("Batas hening (dB, -80..-10)", "-45") { v -> heavy("Menghapus hening...") { Engine.removeSilence(it, v.coerceIn(-80.0, -10.0), 0.3) } } })
        bar.addView(tool("🔁", "Loop") { loopOp() })
        bar.addView(tool("➕", "Gabung") { ask("Jeda antar file (detik)", "0.5") { v -> mergeGap = max(0.0, v); pick(2, true) } })
        bar.addView(tool("📑", "Split") { ask("Split per (detik)", "60") { v -> splitDur(v) } })
        bar.addView(tool("📍", "Split\ntitik") { splitAt() })
        bar.addView(tool("📦", "Kompres") { heavy("Mengecilkan...") { Engine.convert(it, 22050, 1) } })
        bar.addView(tool("🔄", "Batch") { pick(3, true) })
        bar.addView(tool("⚙", "Format") { formatDialog(null) })
        bar.addView(tool("↩", "Undo") { undoOp() })
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(bar) })
        setContentView(root)
        setMode(0)
    }

    // ---------- state ----------
    private fun setMode(m: Int) {
        mode = m; wave.mode = m
        tabA.setTextColor(if (m == 0) ACC else Color.LTGRAY); tabB.setTextColor(if (m == 1) ACC else Color.LTGRAY)
        tabA.setTypeface(null, if (m == 0) Typeface.BOLD else Typeface.NORMAL); tabB.setTypeface(null, if (m == 1) Typeface.BOLD else Typeface.NORMAL)
        sync()
    }

    private fun rng(): Pair<Int, Int>? {
        val p = pcm ?: return null
        val a = (wave.selA * p.frames).toInt().coerceIn(0, p.frames - 1)
        val b = (wave.selB * p.frames).toInt().coerceIn(a + 1, p.frames)
        return a to b
    }
    private fun range(): Pair<Int, Int>? { val r = rng(); if (r == null) toast("Buka file dulu."); return r }

    private fun tf(sec: Double): String { val m = (sec / 60).toInt(); return String.format(Locale.US, "%02d:%05.2f", m, sec - m * 60) }

    private fun sync() {
        val p = pcm ?: return
        val r = rng() ?: return
        val total = p.frames.toDouble() / p.rate
        val s = r.first.toDouble() / p.rate; val e = r.second.toDouble() / p.rate
        tvStart.text = tf(s); tvEnd.text = tf(e)
        val d = if (mode == 0) e - s else total - (e - s)
        tvDur.text = String.format(Locale.US, "%s\nhasil %.1f dtk", "", d).trim()
        info.text = String.format(Locale.US, "%s • %.1f dtk • %d Hz • %s", name, total, p.rate, if (p.ch == 1) "mono" else "stereo")
    }

    private fun nudge(start: Boolean, d: Double) {
        val p = pcm ?: return toast("Buka file dulu.")
        val len = p.frames.toDouble() / p.rate
        var s = wave.selA * len; var e = wave.selB * len
        if (start) s = (s + d).coerceIn(0.0, e - 0.01) else e = (e + d).coerceIn(s + 0.01, len)
        wave.selA = (s / len).toFloat(); wave.selB = (e / len).toFloat(); wave.invalidate(); sync()
    }

    private fun setPcm(n: Pcm, resetSel: Boolean) {
        playing = false; gen++
        undo = pcm; pcm = n; wave.pcm = n; prevPcm = null; cur = 0; wave.playPos = -1f
        if (resetSel) { wave.selA = 0f; wave.selB = 1f }
        btnPlay.text = "▶"; sync(); status.text = "Selesai."
    }

    private fun undoOp() { val u = undo ?: return toast("Tidak ada yang di-undo."); val c = pcm; setPcm(u, true); undo = null; if (c == null) undo = null; toast("Undo.") }

    private fun work(msg: String, block: () -> Unit) {
        status.text = msg
        Thread { try { block() } catch (e: Throwable) { ui { status.text = "Gagal: ${e.message}" } } }.start()
    }

    private fun heavy(msg: String, op: (Pcm) -> Pcm) {
        val p = pcm ?: return toast("Buka file dulu.")
        work(msg) { val n = op(p); ui { setPcm(n, true) } }
    }

    private fun baseName(u: Uri): String {
        var n = "audio"
        contentResolver.query(u, null, null, null, null)?.use { if (it.moveToFirst()) { val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) n = it.getString(i) } }
        return n.substringBeforeLast('.')
    }

    // ---------- buka / gabung / batch ----------
    private fun pick(code: Int, multi: Boolean) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*"))
        if (multi) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, code)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        val cd = data.clipData
        if (cd != null) { for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) } else data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        if (req == 1) {
            playing = false; gen++
            work("Membaca file...") {
                val p = Engine.decode(this, uris[0]); val n = baseName(uris[0])
                ui { name = n; undo = null; setPcm(p, true); undo = null; status.text = "File dimuat." }
            }
        } else if (req == 3) {
            val f = fmtIdx
            work("Konversi batch...") {
                var ok = 0
                val list = uris.take(10)
                for ((i, u) in list.withIndex()) {
                    ui { status.text = "Konversi ${i + 1}/${list.size}..." }
                    Engine.save(this, Engine.decode(this, u), baseName(u), f)
                    ok++
                }
                ui { status.text = "Batch selesai: $ok file di folder AudioEditor." }
            }
        } else {
            val gap = mergeGap
            val cur0 = pcm
            work("Menggabungkan...") {
                val parts = mutableListOf<Pcm>()
                if (cur0 != null) parts.add(cur0)
                for (u in uris) { if (parts.size >= 10) break; parts.add(Engine.decode(this, u)) }
                if (parts.size < 2) throw IllegalStateException("Pilih minimal 2 file (maks 10)")
                val m = Engine.merge(parts, gap)
                ui { if (cur0 == null) name = "gabungan"; setPcm(m, true); status.text = "Digabung: ${parts.size} file." }
            }
        }
    }

    // ---------- operasi ----------
    private fun result(p: Pcm, r: Pair<Int, Int>, m: Int): Pcm = if (m == 0) Engine.slice(p, r.first, r.second) else Engine.cut(p, r.first, r.second)

    private fun coversAll(p: Pcm, r: Pair<Int, Int>) = mode == 1 && r.second - r.first >= p.frames

    private fun fadeOp(inn: Boolean) = ask("Durasi fade (detik, 1-5)", "2") { s ->
        val r = range()
        if (r != null) setPcm(Engine.fade(pcm!!, r.first, r.second, s.coerceIn(1.0, 5.0), inn), false)
    }

    private fun loopOp() = ask("Ulangi pilihan (kali, 2-20)", "2") { t ->
        val r = range()
        if (r != null) {
            val tt = t.toInt().coerceIn(2, 20)
            if ((r.second - r.first).toLong() * (tt - 1) + pcm!!.frames > 100_000_000L) toast("Hasil terlalu besar.")
            else heavy("Menggandakan...") { Engine.repeatSel(it, r.first, r.second, tt) }
        }
    }

    private fun separate() {
        val p = pcm ?: return toast("Buka file dulu.")
        if (p.ch != 2) return toast("Pemisahan butuh audio stereo.")
        val f = fmtIdx; val nm = name
        work("Memisahkan musik & vokal (bisa 1-2 menit)...") {
            val (v, mu) = Engine.separate(p) { pct -> ui { status.text = "Memisahkan... $pct%" } }
            ui { status.text = "Menyimpan hasil..." }
            Engine.save(this, mu, "${nm}_musik", f)
            Engine.save(this, v, "${nm}_vokal", f)
            ui { status.text = "Selesai: ${nm}_musik dan ${nm}_vokal di folder AudioEditor." }
        }
    }

    private fun splitDur(sec: Double) {
        val p = pcm ?: return toast("Buka file dulu.")
        val per = max(1, (sec * p.rate).toInt())
        val f = fmtIdx; val nm = name
        work("Memecah file...") {
            var a = 0; var k = 1
            while (a < p.frames) {
                val b = min(p.frames, a + per)
                if (p.frames - b < per / 10) { Engine.save(this, Engine.slice(p, a, p.frames), "${nm}_bagian$k", f); break }
                Engine.save(this, Engine.slice(p, a, b), "${nm}_bagian$k", f)
                a = b; k++
                ui { status.text = "Memecah... bagian $k" }
            }
            ui { status.text = "Split selesai ($k bagian) di folder AudioEditor." }
        }
    }

    private fun splitAt() {
        val p = pcm ?: return toast("Buka file dulu.")
        val a = rng()?.first ?: return
        if (a <= 0) return toast("Geser garis kiri ke titik pemisah dulu.")
        val f = fmtIdx; val nm = name
        work("Memecah file...") {
            Engine.save(this, Engine.slice(p, 0, a), "${nm}_bagian1", f)
            Engine.save(this, Engine.slice(p, a, p.frames), "${nm}_bagian2", f)
            ui { status.text = "Split selesai (2 bagian) di folder AudioEditor." }
        }
    }

    // ---------- simpan ----------
    private fun formatDialog(then: (() -> Unit)?) {
        val b = AlertDialog.Builder(this).setTitle("Format simpan")
            .setSingleChoiceItems(FORMATS.map { it.label }.toTypedArray(), fmtIdx) { _, w -> fmtIdx = w }
        if (then != null) b.setPositiveButton("Simpan") { _, _ -> then() } else b.setPositiveButton("OK", null)
        b.setNegativeButton("Batal", null).show()
    }

    private fun saveDialog() {
        if (pcm == null) return toast("Buka file dulu.")
        formatDialog { doSave() }
    }

    /** Potong otomatis sesuai mode, lalu simpan. */
    private fun doSave() {
        val p = pcm ?: return
        val r = range() ?: return
        if (coversAll(p, r)) return toast("Pilihan tidak boleh seluruh file pada mode tengah.")
        val m = mode; val f = fmtIdx; val nm = name
        work("Memotong & menyimpan...") {
            val where = Engine.save(this, result(p, r, m), "${nm}_potong", f)
            ui { status.text = "Tersimpan: $where" }
        }
    }

    // ---------- pemutar ----------
    private fun updatePlayhead() {
        val p = pcm ?: return
        val c = cur
        val of = if (pmode == 0) pa + c else if (c < pa) c else c + (pb - pa)
        wave.playPos = of.toFloat() / p.frames
        wave.postInvalidate()
    }

    private fun seekBy(sec: Double) {
        val pp = prevPcm ?: return
        cur = (cur + (sec * pp.rate).toInt()).coerceIn(0, max(0, pp.frames - 1))
        updatePlayhead()
    }

    private fun togglePlay() {
        if (playing) { playing = false; return }
        val p = pcm ?: return toast("Buka file dulu.")
        val r = range() ?: return
        if (coversAll(p, r)) return toast("Pilihan tidak boleh seluruh file pada mode tengah.")
        val key = "${System.identityHashCode(p)}_${r.first}_${r.second}_$mode"
        if (key != lastKey || prevPcm == null) { prevPcm = result(p, r, mode); cur = 0; lastKey = key }
        val prev = prevPcm!!
        pa = r.first; pb = r.second; pmode = mode
        if (cur >= prev.frames) cur = 0
        playing = true; btnPlay.text = "⏸"
        val my = ++gen
        Thread {
            val mask = if (prev.ch == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
            val minBuf = AudioTrack.getMinBufferSize(prev.rate, mask, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(prev.rate).setChannelMask(mask).build())
                .setBufferSizeInBytes(max(minBuf, 16384)).setTransferMode(AudioTrack.MODE_STREAM).build()
            t.play()
            while (playing && gen == my && cur < prev.frames) {
                val c = cur
                val n = min(4096, prev.frames - c)
                t.write(prev.data, c * prev.ch, n * prev.ch)
                if (gen == my) { cur = c + n; updatePlayhead() }
            }
            t.stop(); t.release()
            if (gen == my) {
                playing = false
                if (cur >= prev.frames) { cur = 0; wave.playPos = -1f; wave.postInvalidate() }
                ui { btnPlay.text = "▶" }
            }
        }.start()
    }
}
