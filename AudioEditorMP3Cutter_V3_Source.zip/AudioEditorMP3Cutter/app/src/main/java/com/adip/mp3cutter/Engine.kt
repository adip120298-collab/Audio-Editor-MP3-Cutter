package com.adip.mp3cutter

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import com.naman14.androidlame.LameBuilder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.max
import kotlin.math.min

class Fmt(val label: String, val kind: String, val kbps: Int)

val FORMATS = listOf(
    Fmt("WAV", "wav", 0),
    Fmt("MP3 128 kbps", "mp3", 128), Fmt("MP3 192 kbps", "mp3", 192), Fmt("MP3 256 kbps", "mp3", 256), Fmt("MP3 320 kbps", "mp3", 320),
    Fmt("M4A 64 kbps (kecil)", "m4a", 64), Fmt("M4A 128 kbps", "m4a", 128), Fmt("M4A 192 kbps", "m4a", 192), Fmt("M4A 256 kbps", "m4a", 256), Fmt("M4A 320 kbps", "m4a", 320),
    Fmt("M4R nada dering iPhone", "m4r", 192),
    Fmt("OGG Opus 96 kbps", "ogg", 96), Fmt("OGG Opus 160 kbps", "ogg", 160),
    Fmt("FLAC (lossless)", "flac", 0)
)

class Pcm(val data: ShortArray, val rate: Int, val ch: Int) {
    val frames: Int get() = data.size / ch
}

object Engine {
    // ---------- Decode (audio atau video -> PCM 16-bit) ----------
    fun decode(ctx: Context, uri: Uri): Pcm {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var idx = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { idx = i; fmt = f; break }
        }
        if (idx < 0 || fmt == null) throw IllegalStateException("Tidak ada trek audio di file ini")
        ex.selectTrack(idx)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0)
        codec.start()
        var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var buf = ShortArray(1 shl 20)
        var n = 0
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false
        while (!outDone) {
            if (!inDone) {
                val i = codec.dequeueInputBuffer(10000)
                if (i >= 0) {
                    val ib = codec.getInputBuffer(i)!!
                    val sz = ex.readSampleData(ib, 0)
                    if (sz < 0) {
                        codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inDone = true
                    } else {
                        codec.queueInputBuffer(i, 0, sz, ex.sampleTime, 0)
                        ex.advance()
                    }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10000)
            if (o >= 0) {
                val ob = codec.getOutputBuffer(o)!!
                ob.position(info.offset)
                ob.limit(info.offset + info.size)
                val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                val cnt = sb.remaining()
                if (n + cnt > buf.size) buf = buf.copyOf(max(buf.size * 2, n + cnt))
                sb.get(buf, n, cnt)
                n += cnt
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
            } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val f = codec.outputFormat
                rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            }
        }
        codec.stop(); codec.release(); ex.release()
        n -= n % ch
        val p = Pcm(buf.copyOf(n), rate, ch)
        return if (ch > 2) convert(p, rate, 2) else p
    }

    // ---------- Operasi ----------
    fun slice(p: Pcm, a: Int, b: Int) = Pcm(p.data.copyOfRange(a * p.ch, b * p.ch), p.rate, p.ch)

    fun cut(p: Pcm, a: Int, b: Int): Pcm {
        val out = ShortArray(p.data.size - (b - a) * p.ch)
        p.data.copyInto(out, 0, 0, a * p.ch)
        p.data.copyInto(out, a * p.ch, b * p.ch, p.data.size)
        return Pcm(out, p.rate, p.ch)
    }

    fun fade(p: Pcm, a: Int, b: Int, sec: Double, fadeIn: Boolean): Pcm {
        val d = p.data.copyOf()
        val n = min((sec * p.rate).toInt(), b - a)
        for (i in 0 until n) {
            val g = i.toFloat() / n
            val fr = if (fadeIn) a + i else b - 1 - i
            for (c in 0 until p.ch) { val k = fr * p.ch + c; d[k] = (d[k] * g).toInt().toShort() }
        }
        return Pcm(d, p.rate, p.ch)
    }

    fun gain(p: Pcm, a: Int, b: Int, f: Float): Pcm {
        val d = p.data.copyOf()
        for (k in a * p.ch until b * p.ch) d[k] = (d[k] * f).toInt().coerceIn(-32768, 32767).toShort()
        return Pcm(d, p.rate, p.ch)
    }

    fun normalize(p: Pcm): Pcm {
        var peak = 0
        for (s in p.data) peak = max(peak, abs(s.toInt()))
        if (peak == 0) return p
        return gain(p, 0, p.frames, 0.97f * 32767f / peak)
    }

    fun merge(list: List<Pcm>, gapSec: Double): Pcm {
        val r = list[0].rate
        val c = list[0].ch
        val parts = list.map { convert(it, r, c) }
        val gap = (gapSec * r).toInt() * c
        var total = gap * (parts.size - 1)
        for (q in parts) total += q.data.size
        val out = ShortArray(total)
        var pos = 0
        parts.forEachIndexed { i, q ->
            q.data.copyInto(out, pos)
            pos += q.data.size
            if (i < parts.size - 1) pos += gap
        }
        return Pcm(out, r, c)
    }

    fun convert(p: Pcm, rate: Int, ch: Int): Pcm {
        if (p.rate == rate && p.ch == ch) return p
        val outFrames = (p.frames.toLong() * rate / p.rate).toInt()
        val out = ShortArray(outFrames * ch)
        val step = p.rate.toDouble() / rate
        for (i in 0 until outFrames) {
            val pos = i * step
            val i0 = min(pos.toInt(), p.frames - 1)
            val i1 = min(i0 + 1, p.frames - 1)
            val f = (pos - i0).toFloat()
            for (c in 0 until ch) {
                val v0 = smp(p, i0, c, ch)
                val v1 = smp(p, i1, c, ch)
                out[i * ch + c] = (v0 + (v1 - v0) * f).toInt().toShort()
            }
        }
        return Pcm(out, rate, ch)
    }

    private fun smp(p: Pcm, fr: Int, c: Int, dch: Int): Float {
        if (p.ch == dch) return p.data[fr * p.ch + c].toFloat()
        if (dch == 1) {
            var s = 0f
            for (k in 0 until p.ch) s += p.data[fr * p.ch + k].toFloat()
            return s / p.ch
        }
        return p.data[fr * p.ch + min(c, p.ch - 1)].toFloat()
    }

    // ---------- Encode ----------
    fun writeWav(p: Pcm, os: OutputStream) {
        val len = p.data.size * 2
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + len); h.put("WAVE".toByteArray()); h.put("fmt ".toByteArray())
        h.putInt(16); h.putShort(1); h.putShort(p.ch.toShort()); h.putInt(p.rate)
        h.putInt(p.rate * p.ch * 2); h.putShort((p.ch * 2).toShort()); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(len)
        os.write(h.array())
        val bb = ByteBuffer.allocate(65536).order(ByteOrder.LITTLE_ENDIAN)
        var i = 0
        while (i < p.data.size) {
            bb.clear()
            val n = min(bb.capacity() / 2, p.data.size - i)
            for (k in 0 until n) bb.putShort(p.data[i + k])
            os.write(bb.array(), 0, n * 2)
            i += n
        }
    }

    // ---------- Tahap 2: operasi lanjutan ----------
    fun repeatSel(p: Pcm, a: Int, b: Int, times: Int): Pcm {
        val seg = p.data.copyOfRange(a * p.ch, b * p.ch)
        val extra = times - 1
        val out = ShortArray(p.data.size + seg.size * extra)
        p.data.copyInto(out, 0, 0, b * p.ch)
        var pos = b * p.ch
        for (k in 0 until extra) { seg.copyInto(out, pos); pos += seg.size }
        p.data.copyInto(out, pos, b * p.ch, p.data.size)
        return Pcm(out, p.rate, p.ch)
    }

    fun removeSilence(p: Pcm, db: Double, minSec: Double): Pcm {
        val blk = max(1, p.rate / 100)
        val th = 32768.0 * 10.0.pow(db / 20.0)
        val nb = p.frames / blk
        val silent = BooleanArray(nb)
        for (b in 0 until nb) {
            var s = 0.0
            for (i in 0 until blk) { val v = p.data[(b * blk + i) * p.ch].toDouble(); s += v * v }
            silent[b] = sqrt(s / blk) < th
        }
        val minB = max(1, (minSec * 100).toInt())
        val out = ShortArray(p.data.size)
        var n = 0
        fun copyBlocks(from: Int, cnt: Int) {
            System.arraycopy(p.data, from * blk * p.ch, out, n, cnt * blk * p.ch); n += cnt * blk * p.ch
        }
        var b = 0
        while (b < nb) {
            if (silent[b]) {
                var e = b
                while (e < nb && silent[e]) e++
                val len = e - b
                copyBlocks(b, if (len >= minB) min(len, 8) else len)
                b = e
            } else { copyBlocks(b, 1); b++ }
        }
        val rest = p.data.size - nb * blk * p.ch
        if (rest > 0) { System.arraycopy(p.data, nb * blk * p.ch, out, n, rest); n += rest }
        return if (n == 0) p else Pcm(out.copyOf(n), p.rate, p.ch)
    }

    /** Ubah kecepatan tanpa ubah nada (WSOLA). speed 0.5..2.0 */
    fun stretch(p: Pcm, speed: Double): Pcm {
        if (abs(speed - 1.0) < 1e-3) return p
        val ch = p.ch; val n = 2048; val h = n / 2; val d = 384
        val outFrames = (p.frames / speed).toInt()
        val out = FloatArray((outFrames + n) * ch)
        val win = FloatArray(n) { (0.5 - 0.5 * cos(2 * PI * it / n)).toFloat() }
        var prev = 0
        var k = 0
        while (k.toLong() * h < outFrames) {
            val ideal = (k.toLong() * h * speed).toInt()
            if (ideal >= p.frames) break
            var pos = ideal
            val target = prev + h
            if (k > 0 && target + n <= p.frames) {
                var best = -1e30
                var dd = -d
                while (dd <= d) {
                    val c = ideal + dd
                    if (c >= 0 && c + n <= p.frames) {
                        var s = 0.0
                        var i = 0
                        while (i < n) { s += p.data[(target + i) * ch].toDouble() * p.data[(c + i) * ch]; i += 8 }
                        if (s > best) { best = s; pos = c }
                    }
                    dd += 4
                }
            }
            for (i in 0 until n) {
                val src = pos + i
                if (src >= p.frames) break
                val o = k * h + i
                for (c in 0 until ch) out[o * ch + c] += p.data[src * ch + c] * win[i]
            }
            prev = pos; k++
        }
        val res = ShortArray(outFrames * ch)
        for (i in res.indices) res[i] = out[i].toInt().coerceIn(-32768, 32767).toShort()
        return Pcm(res, p.rate, ch)
    }

    /** Ubah nada tanpa ubah kecepatan. r = rasio frekuensi (2^(semiton/12)) */
    fun pitch(p: Pcm, r: Double): Pcm {
        if (abs(r - 1.0) < 1e-3) return p
        val s = stretch(p, 1.0 / r)
        val q = Pcm(s.data, 100000, s.ch)
        val o = convert(q, (100000 / r).toInt(), s.ch)
        return Pcm(o.data, p.rate, p.ch)
    }

    // ---------- Encoder ----------
    private val okRates = intArrayOf(8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000)

    private fun runEncoder(p: Pcm, enc: MediaCodec, onFormat: (MediaFormat) -> Unit, onData: (ByteBuffer, MediaCodec.BufferInfo) -> Unit) {
        enc.start()
        var pos = 0
        var inDone = false
        var outDone = false
        val info = MediaCodec.BufferInfo()
        while (!outDone) {
            if (!inDone) {
                val i = enc.dequeueInputBuffer(10000)
                if (i >= 0) {
                    val ib = enc.getInputBuffer(i)!!
                    ib.clear()
                    var chunk = min(ib.capacity() / 2, p.data.size - pos)
                    chunk -= chunk % p.ch
                    val t = pos / p.ch * 1_000_000L / p.rate
                    if (chunk <= 0) {
                        enc.queueInputBuffer(i, 0, 0, t, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inDone = true
                    } else {
                        ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(p.data, pos, chunk)
                        enc.queueInputBuffer(i, 0, chunk * 2, t, 0)
                        pos += chunk
                    }
                }
            }
            val o = enc.dequeueOutputBuffer(info, 10000)
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                onFormat(enc.outputFormat)
            } else if (o >= 0) {
                val ob = enc.getOutputBuffer(o)!!
                if (info.size > 0) {
                    ob.position(info.offset)
                    ob.limit(info.offset + info.size)
                    onData(ob, info)
                }
                enc.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
            }
        }
        enc.stop(); enc.release()
    }

    /** AAC (M4A/M4R) atau Opus (OGG) lewat MediaCodec + MediaMuxer. */
    fun encodeMuxed(src: Pcm, out: File, bitrate: Int, opus: Boolean) {
        val p = if (opus) convert(src, 48000, min(src.ch, 2)) else if (src.rate in okRates) src else convert(src, 44100, min(src.ch, 2))
        val mime = if (opus) "audio/opus" else MediaFormat.MIMETYPE_AUDIO_AAC
        val fmt = MediaFormat.createAudioFormat(mime, p.rate, p.ch)
        if (!opus) fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
        fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 65536)
        val enc = MediaCodec.createEncoderByType(mime)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        if (out.exists()) out.delete()
        val mux = MediaMuxer(out.path, if (opus) MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG else MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var started = false
        runEncoder(p, enc, { f -> track = mux.addTrack(f); mux.start(); started = true }) { ob, info ->
            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0 && started) mux.writeSampleData(track, ob, info)
        }
        if (started) mux.stop()
        mux.release()
    }

    /** FLAC mentah lewat encoder bawaan Android (header ikut ditulis dari buffer konfigurasi). */
    fun encodeFlac(p: Pcm, out: File) {
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_FLAC, p.rate, p.ch)
        fmt.setInteger(MediaFormat.KEY_FLAC_COMPRESSION_LEVEL, 5)
        fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 65536)
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_FLAC)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        out.outputStream().use { fos ->
            val tmp = ByteArray(65536)
            runEncoder(p, enc, { }) { ob, info ->
                val n = info.size
                val b = if (n <= tmp.size) tmp else ByteArray(n)
                ob.get(b, 0, n)
                fos.write(b, 0, n)
            }
        }
    }

    /** MP3 lewat LAME (library TAndroidLame). Selalu stereo agar aman. */
    fun encodeMp3(src: Pcm, os: OutputStream, kbps: Int) {
        val r = if (src.rate in okRates) src.rate else 44100
        val p = convert(convert(src, r, 2), r, 2)
        val lame = LameBuilder().setInSampleRate(r).setOutChannels(2).setOutBitrate(kbps).setOutSampleRate(r).setQuality(3).build()
        val mp3 = ByteArray((1.25 * 8192).toInt() + 7200)
        var i = 0
        while (i < p.frames) {
            val n = min(8192, p.frames - i)
            val w = lame.encodeBufferInterLeaved(p.data.copyOfRange(i * 2, (i + n) * 2), n, mp3)
            if (w > 0) os.write(mp3, 0, w)
            i += n
        }
        val w = lame.flush(mp3)
        if (w > 0) os.write(mp3, 0, w)
        lame.close()
    }

    /** idx = indeks di FORMATS. Hasil ke Music/AudioEditor (M4R ke Download/AudioEditor). */
    fun save(ctx: Context, p: Pcm, rawName: String, idx: Int): String {
        val f = FORMATS[idx]
        val name = rawName.replace(Regex("[^A-Za-z0-9 _.-]"), "_")
        val ext = f.kind
        val mime = when (f.kind) { "wav" -> "audio/wav"; "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"; "ogg" -> "audio/ogg"; "flac" -> "audio/flac"; else -> "application/octet-stream" }
        val dir = if (f.kind == "m4r") "Download/AudioEditor" else "Music/AudioEditor"
        val coll = if (f.kind == "m4r") MediaStore.Downloads.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.$ext")
        cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, dir)
        val res = ctx.contentResolver
        if (f.kind == "wav" || f.kind == "mp3") {
            val uri = res.insert(coll, cv)!!
            res.openOutputStream(uri)!!.use { if (f.kind == "wav") writeWav(p, it) else encodeMp3(p, it, f.kbps) }
        } else {
            val tmp = File(ctx.cacheDir, "tmp_export.bin")
            when (f.kind) {
                "ogg" -> encodeMuxed(p, tmp, f.kbps * 1000, true)
                "flac" -> encodeFlac(p, tmp)
                else -> encodeMuxed(p, tmp, f.kbps * 1000, false)
            }
            val uri = res.insert(coll, cv)!!
            res.openOutputStream(uri)!!.use { os -> tmp.inputStream().use { it.copyTo(os) } }
            tmp.delete()
        }
        return "$dir/$name.$ext"
    }

    // ---------- Pisah vokal & musik (DSP: ekstraksi kanal tengah, tanpa AI) ----------
    private fun fft(re: DoubleArray, im: DoubleArray, inv: Boolean) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val tr = re[i]; re[i] = re[j]; re[j] = tr; val ti = im[i]; im[i] = im[j]; im[j] = ti }
        }
        var len = 2
        while (len <= n) {
            val ang = 2 * PI / len * (if (inv) 1 else -1)
            val wr = cos(ang); val wi = sin(ang)
            val hl = len / 2
            var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until hl) {
                    val a = i + k; val b = a + hl
                    val vr = re[b] * cr - im[b] * ci
                    val vi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - vr; im[b] = im[a] - vi
                    re[a] += vr; im[a] += vi
                    val nc = cr * wr - ci * wi
                    ci = cr * wi + ci * wr; cr = nc
                }
                i += len
            }
            len = len shl 1
        }
        if (inv) for (i in 0 until n) { re[i] /= n; im[i] /= n }
    }

    /** Hasil: (vokal, musik). Butuh stereo. Vokal = komponen yang sama di kiri-kanan (tengah) pada 120 Hz ke atas. */
    fun separate(p: Pcm, onProgress: (Int) -> Unit): Pair<Pcm, Pcm> {
        if (p.ch != 2) throw IllegalStateException("Butuh audio stereo")
        val n = 2048; val h = n / 2; val frames = p.frames
        if (frames.toLong() * 2 > 60_000_000L) throw IllegalStateException("File terlalu panjang untuk dipisahkan (maks sekitar 10 menit)")
        val win = DoubleArray(n) { sin(PI * (it + 0.5) / n) }
        val voc = FloatArray(frames * 2)
        val zr = DoubleArray(n); val zi = DoubleArray(n); val wr = DoubleArray(n); val wi = DoubleArray(n)
        val nf = frames / h + 2
        val binHz = p.rate.toDouble() / n
        for (f in 0 until nf) {
            val s0 = f * h - h
            for (i in 0 until n) {
                val idx = s0 + i
                if (idx in 0 until frames) { zr[i] = p.data[idx * 2] * win[i]; zi[i] = p.data[idx * 2 + 1] * win[i] } else { zr[i] = 0.0; zi[i] = 0.0 }
            }
            fft(zr, zi, false)
            for (k in 0 until n) {
                val m = (n - k) % n
                val lr = (zr[k] + zr[m]) / 2; val li = (zi[k] - zi[m]) / 2
                val rr = (zi[k] + zi[m]) / 2; val ri = -(zr[k] - zr[m]) / 2
                val ml = sqrt(lr * lr + li * li); val mr = sqrt(rr * rr + ri * ri)
                val dr = lr - rr; val di = li - ri
                val sim = 1.0 - sqrt(dr * dr + di * di) / (ml + mr + 1e-9)
                var mask = ((sim - 0.55) / 0.4).coerceIn(0.0, 1.0)
                mask = mask * mask * (3 - 2 * mask)
                val hz = min(k, n - k) * binHz
                if (hz < 120) mask = 0.0 else if (hz < 250) mask *= (hz - 120) / 130
                val vlr = lr * mask; val vli = li * mask; val vrr = rr * mask; val vri = ri * mask
                wr[k] = vlr - vri; wi[k] = vli + vrr
            }
            fft(wr, wi, true)
            for (i in 0 until n) {
                val idx = s0 + i
                if (idx in 0 until frames) { voc[idx * 2] += (wr[i] * win[i]).toFloat(); voc[idx * 2 + 1] += (wi[i] * win[i]).toFloat() }
            }
            if (f % 100 == 0) onProgress(f * 100 / nf)
        }
        val vd = ShortArray(frames * 2); val md = ShortArray(frames * 2)
        for (i in vd.indices) {
            val v = voc[i].toInt().coerceIn(-32768, 32767)
            vd[i] = v.toShort(); md[i] = (p.data[i] - v).coerceIn(-32768, 32767).toShort()
        }
        return Pair(Pcm(vd, p.rate, 2), Pcm(md, p.rate, 2))
    }
}
